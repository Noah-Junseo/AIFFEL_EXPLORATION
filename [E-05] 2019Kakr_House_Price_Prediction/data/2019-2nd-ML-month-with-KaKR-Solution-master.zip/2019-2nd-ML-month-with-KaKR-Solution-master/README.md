## 2019 2nd ML month with KaKR - House Price Prediction Solution
### Kaggle Kernel
* https://www.kaggle.com/tmheo74/11th-solution-public-98316-private-99336
